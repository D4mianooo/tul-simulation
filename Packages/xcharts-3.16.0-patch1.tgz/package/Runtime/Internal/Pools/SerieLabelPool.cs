using System.Collections.Generic;
using UnityEngine;

namespace XCharts.Runtime
{
    public static class SerieLabelPool
    {
        private static readonly Stack<GameObject> m_Stack = new Stack<GameObject>(200);
        private static Dictionary<int, bool> m_ReleaseDic = new Dictionary<int, bool>(1000);

        public static GameObject Get(string name, Transform parent, LabelStyle label, Color color,
            float iconWidth, float iconHeight, ThemeStyle theme)
        {
            GameObject element;
            if (m_Stack.Count == 0 || !Application.isPlaying)
            {
                element = CreateSerieLabel(name, parent, label, color, iconWidth, iconHeight, theme);
            }
            else
            {
                element = m_Stack.Pop();
                if (element == null)
                {
                    element = CreateSerieLabel(name, parent, label, color, iconWidth, iconHeight, theme);
                }
                m_ReleaseDic.Remove(GetId(element));
                element.name = name;
                element.transform.SetParent(parent);
                var text = new ChartText(element);
                text.SetColor(color);
                text.SetFontAndSizeAndStyle(label.textStyle, theme.common);
                ChartHelper.SetActive(element, true);
            }
            element.transform.localEulerAngles = new Vector3(0, 0, label.rotate);
            return element;
        }

        public static void Release(GameObject element)
        {
            if (element == null) return;
            ChartHelper.SetActive(element, false);
            if (!Application.isPlaying) return;
            if (!m_ReleaseDic.ContainsKey(GetId(element)))
            {
                m_Stack.Push(element);
                m_ReleaseDic.Add(GetId(element), true);
            }
        }

        public static void ReleaseAll(Transform parent)
        {
            int count = parent.childCount;
            for (int i = 0; i < count; i++)
            {
                Release(parent.GetChild(i).gameObject);
            }
        }

#if UNITY_6000_0_OR_NEWER
        // Patched for Unity 6.6: EntityId -> int cast is now a compile error (CS0619).
        // Object.GetHashCode() is based on the object identity, unique while the object lives.
        private static int GetId(GameObject obj) { return obj.GetHashCode(); }
#else
        private static int GetId(GameObject obj) { return obj.GetInstanceID(); }
#endif

        public static void ClearAll()
        {
            m_Stack.Clear();
            m_ReleaseDic.Clear();
        }

        private static GameObject CreateSerieLabel(string name, Transform parent, LabelStyle labelStyle, Color color,
            float iconWidth, float iconHeight, ThemeStyle theme)
        {
            var label = ChartHelper.AddChartLabel(name, parent, labelStyle, theme.common,
                "", color, TextAnchor.MiddleCenter);
            label.SetActive(labelStyle.show, true);
            return label.gameObject;
        }
    }
}